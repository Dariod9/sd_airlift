java -cp .:../genclass.jar clientSide.main.$1
