MACHINE=sd304@l040101-ws04.ua.pt
#!/bin/bash

echo "Executing shared Regions."
xterm  -T "General Repository" -hold -e "./reposRun.sh" &
sleep 2
xterm  -T "Airplane" -hold -e "./airplaneRun.sh" &
sleep 2
xterm  -T "Departure Airport" -hold -e "./depAirportRun.sh" &
sleep 2
xterm  -T "Destination Airport" -hold -e "./destAirportRun.sh" &
sleep 2




