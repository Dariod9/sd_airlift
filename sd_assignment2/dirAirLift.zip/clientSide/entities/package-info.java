/**
 * Client Side Entities
 */
package clientSide.entities;

