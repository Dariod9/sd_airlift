/**
 * Client side main
 */
package clientSide.main;

