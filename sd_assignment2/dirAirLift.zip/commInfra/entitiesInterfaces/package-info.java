/**
 * commInfra Entities Interfaces
 */
package commInfra.entitiesInterfaces;

